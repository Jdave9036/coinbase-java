package com.coinbase.api.exception;

public class CoinbaseException extends Exception {
    
    public CoinbaseException() {
	super();
    }
    
    public CoinbaseException(String message) {
	super(message);
    }
    
}
