package com.coinbase.api.exception;

public class UnspecifiedAccount extends CoinbaseException {

}
